function copyMailToClipBoard() {    
    navigator.clipboard.writeText("yogeshwaran9397@hotmail.com");    
  }
    